package it.unicam.cs.pa2021.battaglianavale;

public interface Location {
}
