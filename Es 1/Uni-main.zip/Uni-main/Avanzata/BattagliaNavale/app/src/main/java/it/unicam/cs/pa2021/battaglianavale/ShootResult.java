package it.unicam.cs.pa2021.battaglianavale;

public enum ShootResult {
	MISS,
	HIT,
	SUNK
}
