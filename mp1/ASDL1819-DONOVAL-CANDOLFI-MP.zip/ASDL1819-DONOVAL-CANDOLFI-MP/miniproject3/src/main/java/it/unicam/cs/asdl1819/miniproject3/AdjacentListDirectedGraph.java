package it.unicam.cs.asdl1819.miniproject3;

import java.util.Iterator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Implementazione dell'interfaccia {@code Graph<V,E>} per grafi diretti
 * utilizzando liste di adiacenza per la rappresentazione.
 * 
 * Questa classe non supporta le operazioni di rimozione di nodi e archi e le
 * operazioni indicizzate di ricerca di nodi e archi.
 * 
 * @author Luca Tesei 		*Donoval Candolfi* (implementazione)
 *
 * @param <V> etichette dei nodi
 * @param <E> etichette degli archi
 */
public class AdjacentListDirectedGraph<V, E> implements Graph<V, E> {
	private Map<GraphNode<V>, Set<GraphEdge<V, E>>> listaAdj; // creo mappa dei nodi e creo un set con gli archi e nodi mettendoli in una lista														
	private GraphNode<V> ultimoNodo = null; 		// creo e assegno il nodo "ultimoNodo" a null
	private int numNodi; 		// costruisco i nodi
	private int numArchi; 		// costruisco gli archi

	/**
	 * Crea un grafo vuoto.
	 */
	public AdjacentListDirectedGraph() {
		this.listaAdj = new HashMap<GraphNode<V>, Set<GraphEdge<V, E>>>();
		this.numArchi = 0;
		this.numNodi = 0;
		this.ultimoNodo = null;
	}

	public int nodeCount() {
		return listaAdj.keySet().size();
	}

	public int edgeCount() {
		return numArchi;
	}

	public int size() {
		return listaAdj.keySet().size() + this.numArchi;
	}

	public boolean isEmpty() {
		return this.listaAdj.keySet().isEmpty();
	}

	public void clear() {
		this.listaAdj.keySet().clear();
	}

	public boolean isDirected() {
		return true;
	}

	public Set<GraphNode<V>> getNodes() {
		return this.listaAdj.keySet();
	}

	public boolean addNode(GraphNode<V> node) {

		if (node == null) {
			throw new NullPointerException();
		}
		if (this.listaAdj.keySet().contains(node)) { // controllo se il nodo � gi� presente nella lista
			return false;
		}

		node.setPrevious(ultimoNodo); // se � presente setto il precedente come ultimoNodo a node

		this.listaAdj.put(node, new HashSet<GraphEdge<V, E>>()); // inserisco il nodo con insieme degli archi associati vuoto
		ultimoNodo = node;
		numNodi++;
		return true;

	}

	public boolean removeNode(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException("Tentativo di rimuovere un nodo null");
		} else {
			throw new UnsupportedOperationException("Rimozione dei nodi non supportata");
		}
	}

	public boolean containsNode(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException();
		}
		return this.listaAdj.keySet().contains(node);
	}

	public int getNodeIndex(V label) {
		if (label == null)
			throw new NullPointerException("Tentativo di ricercare un nodo con etichetta null");
		throw new UnsupportedOperationException("Ricerca dei nodi con indice non supportata");
	}

	public GraphNode<V> getNodeAtIndex(int i) {
		throw new UnsupportedOperationException("Ricerca dei nodi con indice non supportata");
	}

	public Set<GraphNode<V>> getAdjacentNodes(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node) == false) { // se la lista non contiene il mapping del nodo ,lancio l'eccezione

			throw new IllegalArgumentException();
		}
		Set<GraphEdge<V, E>> archiCollegati = this.listaAdj.get(node);
		if (archiCollegati == null) {
			throw new IllegalArgumentException();
		}
		Set<GraphNode<V>> result = new HashSet<GraphNode<V>>();
		for (GraphEdge<V, E> temp : archiCollegati)
			if (temp.getNode1().equals(node)) {
				result.add(temp.getNode2());
			} else {
				result.add(temp.getNode1());
			}
		return result;
	}

	public Set<GraphNode<V>> getPredecessorNodes(GraphNode<V> node) {

		if (this.isDirected() == false) { 			// se il grafo comprendente i nodi non � orientato, lancio l'eccezione
			throw new UnsupportedOperationException();
		}
		if (node == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node) == false) {
			throw new IllegalArgumentException();
		}

		Set<GraphEdge<V, E>> connx_archi = this.listaAdj.get(node);
		if (connx_archi == null) {
			throw new IllegalArgumentException();
		}

		Set<GraphNode<V>> result = new HashSet<GraphNode<V>>(); 	//costruisco il set dei nodi con l'insieme dei nodi associati vuoto
		
		for (GraphEdge<V, E> temp : connx_archi) {
			if (temp.getNode2().equals(node)) {
				result.add(temp.getNode1());
			}
		}
		return result;
		
	}

	public Set<GraphEdge<V, E>> getEdges() {

		HashSet<GraphEdge<V, E>> temp = new HashSet<GraphEdge<V, E>>();
		for (GraphNode<V> node : listaAdj.keySet())
			temp.addAll(listaAdj.get(node));
		return temp;

	}

	public boolean addEdge(GraphEdge<V, E> edge) {

		if (edge == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(edge.getNode1()) == false || listaAdj.containsKey(edge.getNode2()) == false) { // controllo che entrambi gli archi possiedono una chiave nella lista di adiacenza																							 
			throw new IllegalArgumentException();
		}
		if (edge.isDirected() && this.isDirected() == false || this.isDirected() && edge.isDirected() == false) { // controllo che entrambi i nodi con relativi archi sono orientati
			throw new IllegalArgumentException();
		}
		if (containsEdge(edge)) {
			return false;
		}
		boolean result = this.listaAdj.get(edge.getNode1()).add(edge); // Inserisco l'arco nella lista di adiacenza nel
																		// nodo 1 e nel nodo 2
		result = result && this.listaAdj.get(edge.getNode2()).add(edge);
		numArchi++;
		return result;
	}

	public boolean removeEdge(GraphEdge<V, E> edge) {
		throw new UnsupportedOperationException("Rimozione degli archi non supportata");
	}

	public boolean containsEdge(GraphEdge<V, E> edge) {
		if (edge == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(edge.getNode1()) == false) {
			throw new IllegalArgumentException();
		}
		if (listaAdj.containsKey(edge.getNode2()) == false) {
			throw new IllegalArgumentException();
		}
		for (GraphNode<V> node : listaAdj.keySet()) {     //finch� ho gli archi con relativo nodo contenuti nella lista
			if (getEdges(node).contains(edge))
				return true;
		}
		return false;
	}

	public Set<GraphEdge<V, E>> getEdges(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node) == false) {
			throw new IllegalArgumentException();
		}
		HashSet<GraphEdge<V, E>> temp = new HashSet<GraphEdge<V, E>>();   //creo un hashset temp in cui memorizzo gli archi

		temp.addAll(listaAdj.get(node));

		return temp;
	}

	public Set<GraphEdge<V, E>> getIngoingEdges(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node) == false) {
			throw new IllegalArgumentException();
		}
		if (this.isDirected() == false) {
			throw new UnsupportedOperationException();
		}
		if (!listaAdj.containsKey(node)) {
			throw new IllegalArgumentException();
		}

		Iterator<GraphEdge<V, E>> itero = getEdges().iterator(); 	// esploro i nodi con iterator

		Set<GraphEdge<V, E>> res = new HashSet<GraphEdge<V, E>>();
		GraphEdge<V, E> temp;
		while (itero.hasNext()) {
			temp = itero.next();
			if (temp.getNode2() == node) {
				res.add(temp);
			}
		}
		return res;
	}

	public int getDegree(GraphNode<V> node) {
		if (node == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node) == false) {
			throw new IllegalArgumentException();
		}
		return getEdges(node).size();
	}

	public Set<GraphEdge<V, E>> getEdgesBetween(int index1, int index2) {
		throw new UnsupportedOperationException("Operazioni con indici non supportate");
	}

	public Set<GraphEdge<V, E>> getEdgesBetween(GraphNode<V> node1, GraphNode<V> node2) {
		if (node1 == null || node2 == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsKey(node1) == false) {
			throw new IllegalArgumentException();
		}
		if (listaAdj.containsKey(node2) == false) {
			throw new IllegalArgumentException();
		}

		HashSet<GraphEdge<V, E>> set = new HashSet<GraphEdge<V, E>>();

		for (GraphNode<V> temp : listaAdj.keySet()) {
			if (temp == node1) {
				set.addAll(getEdges(temp));
			}
			if (temp == node2) {
				set.addAll(getEdges(temp));
			}
		}
		return set;
	}

	public GraphNode<V> getNode(V label) {
		if (label == null) {
			throw new NullPointerException();
		}

		for (GraphNode<V> n : this.listaAdj.keySet()) { // esploro i nodi e cerco quello con l'etichetta
			if (n.getLabel().equals(label))
				return n;
		}
		throw new IllegalArgumentException(); // se non contiene l'etichetta , lancio l'eccezione
	}
}
