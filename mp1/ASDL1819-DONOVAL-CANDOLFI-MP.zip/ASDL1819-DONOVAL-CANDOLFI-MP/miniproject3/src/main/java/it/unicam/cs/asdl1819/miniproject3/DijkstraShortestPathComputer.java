package it.unicam.cs.asdl1819.miniproject3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Gli oggetti di questa classe sono calcolatori di cammini minimi con sorgente
 * singola su un certo grafo diretto e pesato dato. Il grafo su cui lavorare
 * deve essere passato quando l'oggetto calcolatore viene costruito e non può
 * contenere archi con pesi negativi. Il calcolatore implementa il classico
 * algoritmo di Dijkstra per i cammini minimi con sorgente singola utilizzando
 * una coda con priorità che estrae il minimo in tempo lineare rispetto alla
 * lunghezza della coda. In questo caso il tempo di esecuzione dell'algoritmo di
 * Dijkstra � {@code O(n^2)} dove {@code n} � il numero dei nodi del grafo.
 * 
 * @author Luca Tesei     	*Donoval Candolfi* (implementazione)
 *
 * @param <V> il tipo delle etichette dei nodi del grafo
 * @param <E> il tipo delle etichette degli archi del grafo
 */

public class DijkstraShortestPathComputer<V, E> {

	private AdjacentListDirectedGraph<V, E> listaAdj;			//creo lista adiacenze dei nodi e archi
	private boolean statoEsec;									//creo un controllo dello stato di esecuzione
	private GraphNode<V> ultimoNodo;							//costruisco un nodo come l'ultimo nodo del grafo

	/**
	 * Crea un calcolatore di cammini minimi a sorgente singola per un grafo diretto
	 * e pesato privo di pesi negativi.
	 * 
	 * @param graph il grafo su cui opera il calcolatore di cammini minimi
	 * 
	 * @throws NullPointerException se il grafo passato � nullo
	 * 
	 * @throws IllegalArgumentException se il grafo passato � vuoto
	 * 
	 * @throws IllegalArgumentException se il grafo passato non � diretto
	 * 
	 * @throws IllegalArgumentException se il grafo passato non � pesato, cio�
	 * esiste almeno un arco il cui peso � {@code Double.NaN}.
	 * 
	 * @throws IllegalArgumentException se il grafo passato contiene almeno un peso
	 * negativo.
	 */
	public DijkstraShortestPathComputer(Graph<V, E> graph) {

		if (graph == null) {
			throw new NullPointerException();
		}

		this.listaAdj = (AdjacentListDirectedGraph<V, E>) graph;		//inizializzo la lista adiacenze 

		if (this.listaAdj.isEmpty() == true) {
			throw new IllegalArgumentException();
		}

		if (this.listaAdj.isDirected() == false) {
			throw new IllegalArgumentException();
		}

		for (GraphEdge<V, E> grafoArco : this.listaAdj.getEdges()) {
			if (grafoArco.getWeight() < 0 || Double.isNaN(grafoArco.getWeight())) {			//se l'arco del grafo � negativo o � +infinito lancio l'eccezione
				throw new IllegalArgumentException();
			}
		}

		this.statoEsec = false;
	}

	/**
	 * Inizializza le informazioni necessarie associate ai nodi del grafo associato
	 * a questo calcolatore ed esegue l'algoritmo di Dijkstra sul grafo.
	 * 
	 * @param sourceNode il nodo sorgente da cui calcolare i cammini minimi verso
	 *                   tutti gli altri nodi del grafo
	 * @throws NullPointerException     se il nodo passato � nullo
	 * 
	 * @throws IllegalArgumentException se il nodo passato non esiste nel grafo
	 *                                  associato a questo calcolatore
	 */
	public void computeShortestPathsFrom(GraphNode<V> sourceNode) {

		if (sourceNode == null) {
			throw new NullPointerException();
		}
		if (listaAdj.containsNode(sourceNode) == false) {		//se la lista non contiene il nodo sorgente lancio l'eccezione
			throw new IllegalArgumentException();
		}

		ultimoNodo = sourceNode;		//inizializzo l'ultimo nodo come nodo sorgente

		ultimoNodo.setFloatingPointDistance(0.);    //setto l'ultimo nodo come valore in virgola mobile per la distanza tra i nodi
		
		PriorityQueue<GraphNode<V>> codaVertice = new PriorityQueue<GraphNode<V>>();		//creo una coda con priorit� e inserisco i nodi
		codaVertice.add(ultimoNodo);														//aggiungo alla coda l'ultimo nodo cio� il primo seguendo il principio FIFO

		while (codaVertice.isEmpty() == false) {	    //finche nella coda ci sono elementi
			GraphNode<V> node = codaVertice.poll();		//rimuove l'elemento in testa alla coda

			
			for (GraphEdge<V, E> arco : listaAdj.getEdges(ultimoNodo)) { 	// visita ogni arco uscente

				GraphNode<V> vertice = arco.getNode1();

				double weight = arco.getWeight();									//l'altezza � l'insieme delle altezze degli archi
				double distanceThroughU = node.getFloatingPointDistance() + weight;   			
				if (distanceThroughU < vertice.getFloatingPointDistance()) {		//se la distanza da u � minore della distanza dei vertici
					codaVertice.remove(vertice);									//rimuovo dalla coda il vertice

					vertice.setFloatingPointDistance(distanceThroughU);			
					vertice.setPrevious(node);
					codaVertice.add(vertice);
				}
			}
		}
		statoEsec = true;
	}

	/**
	 * Determina se � stata invocata almeno una volta la procedura di calcolo dei
	 * cammini minimi a partire da un certo nodo sorgente specificato.
	 * 
	 * @return true, se i cammini minimi da un certo nodo sorgente sono stati
	 *         calcolati almeno una volta da questo calcolatore
	 */
	public boolean isComputed() {
		return statoEsec;
	}

	/**
	 * Restituisce il nodo sorgente specificato nell'ultima chiamata effettuata a
	 * {@code computeShortestPathsFrom(GraphNode<V>)}.
	 * 
	 * @return il nodo sorgente specificato nell'ultimo calcolo dei cammini minimi
	 *         effettuato
	 * 
	 * @throws IllegalStateException se non � stato eseguito nemmeno una volta il
	 *                               calcolo dei cammini minimi a partire da un nodo
	 *                               sorgente
	 */
	public GraphNode<V> getLastSource() {
		if (statoEsec == false) {
			throw new IllegalStateException();
		}

		return ultimoNodo;
	}

	/**
	 * Restituisce il grafo su cui opera questo calcolatore.
	 * 
	 * @return il grafo su cui opera questo calcolatore
	 */
	public Graph<V, E> getGraph() {
		return listaAdj;
	}

	/**
	 * Restituisce una lista di archi dal nodo sorgente dell'ultimo calcolo di
	 * cammini minimi al nodo passato. Tale lista corrisponde a un cammino minimo
	 * tra il nodo sorgente e il nodo target passato.
	 * 
	 * @param targetNode il nodo verso cui restituire il cammino minimo dalla
	 *                   sorgente
	 * @return la lista di archi corrispondente al cammino minimo; la lista � vuota
	 *         se il nodo passato � il nodo sorgente. Viene restituito {@code null}
	 *         se il nodo passato non � raggiungibile dalla sorgente
	 * 
	 * @throws NullPointerException     se il nodo passato � nullo
	 * 
	 * @throws IllegalArgumentException se il nodo passato non esiste
	 * 
	 * @throws IllegalStateException    se non � stato eseguito nemmeno una volta il
	 *                                  calcolo dei cammini minimi a partire da un
	 *                                  nodo sorgente
	 * 
	 */
	public List<GraphEdge<V, E>> getShortestPathTo(GraphNode<V> targetNode) {

		if (targetNode == null) {
			throw new NullPointerException();
		}
		if (isComputed() == false) {
			throw new IllegalStateException();
		}

		if (listaAdj.containsNode(targetNode) == false) {		//se la lista non contiene il nodo target lancio l'eccezione
			throw new IllegalArgumentException();
		}

		List<GraphEdge<V, E>> percorso = new ArrayList<GraphEdge<V, E>>();  //lista di tutto il percorso con le posizioni in array dei nodi e archi

		if (ultimoNodo == targetNode) {
			return percorso;
		}

		for (GraphNode<V> v : listaAdj.getNodes()) {		
			if (v == targetNode) {
				break;
			} else if (v.getPrevious() != null) {
				percorso.addAll(listaAdj.getEdgesBetween(v.getPrevious(), v));  //inserisco nel percorso tutti i nodi adiacenti agli archi
			}

			if (percorso.isEmpty()) {
				return null;
			} else {

				Collections.reverse(percorso);    //se nel percorso ho qualcosa ,allora inverto l'ordine della lista del percorso

			}

		}
		return percorso;
	}

	/**
	 * Genera una stringa di descrizione di un path riportando i nodi attraversati e
	 * i pesi degli archi. Nel caso di cammino vuoto genera solo la stringa
	 * {@code "[ ]"}.
	 * 
	 * @param path un cammino minimo
	 * @return una stringa di descrizione del cammino minimo
	 * @throws NullPointerException se il cammino passato � nullo
	 */
	public String printPath(List<GraphEdge<V, E>> path) {
		if (path == null)
			throw new NullPointerException("Richiesta di stampare un path nullo");
		if (path.isEmpty())
			return "[ ]";

		// Costruisco la stringa
		StringBuffer s = new StringBuffer();
		s.append("[ " + path.get(0).getNode1().toString());
		for (int i = 0; i < path.size(); i++)
			s.append(" -- " + path.get(i).getWeight() + " --> " + path.get(i).getNode2().toString());
		s.append(" ]");
		return s.toString();
	}

}
