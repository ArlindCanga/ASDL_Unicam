package it.unicam.cs.asdl1819.miniproject1;

import java.util.HashSet; // Utilizzare questa classe per i set
import java.util.Iterator;
import java.util.Set;
import java.util.*;

/**
 * Un multinsieme è un insieme in cui gli elementi hanno una molteplicità (cioè un numero di 
 * volte che occorrono nell'insieme). Se un elemento ha molteplicità zero
 * allora non appartiene all'insieme. Implementa tutti i metodi dell'interfaccia Multiset
 * 
 * @author Luca Tesei (template) **Donoval Candolfi** (implementazione)
 *
 * @param <E>
 *            il tipo degli elementi del multiset
 */

public class MyMultiset<E> implements Multiset<E> {	
	

	private ArrayList<Integer> set = null;				//Costruttore arraylist di interi della variabile Set inizializzata a null
	private ArrayList<Integer> array_count = null;		//Costruttore arraylist di interi della variabile array_count inizializzata a null

    /**
     * Crea un multiset vuoto.
     */
    public MyMultiset() {
    	
    	set = new ArrayList<Integer>();				//costruzione e allocazione memoria della variabile Set
    	array_count = new ArrayList<Integer>();		//costruzione e allocazione memoria della variabile array_count
    }

    public int size() {								//Iniziallizzo una dimensione intera a 0 e somma la size + il valore presente dell'indice passato di array_count
    	
    	Integer size = 0;
    	for(int i=0;i<array_count.size();i++)
    		size= size+array_count.get(i);
    	return size;
    }

    public int count(Object element) {		//conta gli elementi che vengono inseriti nell'array_count e mi restituisce il numero di volte, e faccio controlli delle condizioni

    	if(element == null)
        	throw new NullPointerException();
    	 int conta=0;
    	 for(int i=0; i<set.size();i++)
    		 if(((Integer)element).equals(set.get(i)))
    			 conta= array_count.get(i);
    	 return conta;
    }

    public int add(E element, int occurrences) {     // aggiunge un valore n per quante volte viene specificato dalle occorrenze
    	int max = (Integer.MAX_VALUE);
    	max = max-count(element);
    	if(element == null)							//lancio l'eccezzione in caso di elemento generico uguale a null
        	throw new NullPointerException();
    	else if(occurrences<0 || occurrences>max)   //lancio l'eccezzione in caso  di non prensenza di valore o di eccesso rispetto al valore massimo possibile di interi
    		throw new IllegalArgumentException();
    	
        int count = count(element);					
        int index = -1;
        if(count>0) {
        	index= searchIndex((Integer)element);   //cerca nell'indice l'elemento passato dal metodo
        	array_count.set(index, array_count.get(index)+occurrences);  //sostituisce i valori dell'array_count con tutti i valori che incontro corrispondenti all'indice inserito piÃ¹ quante volte Ã¨ ripetuto
        	
        }
        	else {
    		set.add((Integer)element);
    		array_count.add((Integer)occurrences);
        }

        return count;
    }

    public void add(E element) {			//metodo che aggiunge determinati elementi + condizioni
    	int max = (Integer.MAX_VALUE);
    	if(element == null)
        	throw new NullPointerException();
    	if(count(element)>=max)
    		throw new IllegalArgumentException();
   
        int count = count(element);
        int index = -1;
        if(count>0) {
        	index= searchIndex((Integer)element);				//cerca nell'indice l'elemento passato dal metodo
        	array_count.set(index, array_count.get(index)+1);	//sostituisce i valori dell'array_count con tutti i valori che incontro corrispondenti all'indice inserito
        }else {
    		set.add((Integer)element);							//aggiungo al set n elementi non presente nell'indice
    		array_count.add(1);									//aggiungo all'array_count un elemento
        }    
        
    }
    

    public int remove(Object element, int occurrences) {		//rimuovo l'elemento dopo averlo cercato nell'indice per quante volte Ã¨ stato ripetuto
    	if(element == null)
        	throw new NullPointerException();
    	else if(occurrences<0)
    		throw new IllegalArgumentException();
    	
    	int max=occurrences;
    	int count = count(element);
    	if(occurrences>count(element))
    		max=count(element);
    	if(count>0) {
    		int index = searchIndex((Integer)element);
    		if(array_count.get(index)-max>0)		
    			array_count.set(index, array_count.get(index)-max);	//sostituisce i valori dell'array_count con tutti i valori che incontro corrispondenti all'indice inserito scalato del valore massimo di occorrenze
    		else {
    			array_count.remove(index);			//rimuovo l'indice dall'array_count 
    			set.remove(index);					//rimuovo l'indice dal set
    		}
    	}
        return count;
    }

    public boolean remove(Object element) {				//metodo che rimuove un elemento dopo averlo cercato nell'indice e rimuovo anche l'indice + condizioni
    	if(element == null)
        	throw new NullPointerException();
    	
    	if(count(element)>0)
    	{
    		int index = searchIndex((Integer)element);
    		if(array_count.get(index)-1>0)									
    			array_count.set(index, array_count.get(index)-1);   //sostituisce i valori dell'array_count con tutti i valori che incontro corrispondenti all'indice inserito scalato di una posizione
    		else {
    			array_count.remove(index);							//rimuovo l'indice dall'array_count 
    			set.remove(index);									//rimuovo l'indice dal set
    		}
    		return true;
    	}
		
        return false;

    }

    public int setCount(E element, int occurrences) {		//imposta un elemento determinate volte all'interno dell'array
    	if(element == null)
        	throw new NullPointerException();
    	else if(occurrences<0)
    		throw new IllegalArgumentException();
    	
    	int count = count(element);
    	if(count(element)>occurrences)										//se l'elemento supera il numero di volte passati dal metodo, rimuove quelli in eccesso
    		remove(((Object)element), ((int)count(element))-occurrences);
    	else if(count(element)<occurrences)									//se l'elemento non supera il numero di volte passati dal metodo, aggiunge quelli mancanti
    		add(((E)element), occurrences-((int)count(element)));
    	
        return count;
    }

    @SuppressWarnings("unchecked")
	public Set<E> elementSet() {				//metodo che aggiunge dentro l'hashset tutti gli elementi presi singolarmente dal set
    	Set<E> elementSet = new HashSet<E>();
    	for(int i=0; i<set.size(); i++)
    		elementSet.add((E)set.get(i));
        return elementSet;
    }

    @SuppressWarnings("unchecked")
    
	public Iterator<E> iterator() {					//metodo che mi restituisce tutti i valori dell'array_tot
    	 Iterator<E> iterator;
    	
    	 @SuppressWarnings({ "rawtypes" })
		ArrayList<Integer> array_tot = new ArrayList();
    	 for(int i=0;i<set.size();i++)
        	 for(int j=0;j<array_count.get(i);j++)		//scorro le posizioni del set (con rispettivi valori) e aggiungo il valore dentro array_tot
        		 array_tot.add(set.get(i));
    	 
         iterator = (Iterator<E>)array_tot.iterator();		//mi richiama la lista dei valori presenti nell'array_tot
         
         return iterator;
    }

    public boolean contains(Object element) {		//metodo che controlla se l'elemento Ã¨ stato giÃ  inserito confrontandolo con l'ArrayList set
    	if(element == null)
        	throw new NullPointerException();
    	
    	for(int i=0; i<set.size(); i++)
    		if(set.get(i).equals((Integer)element))
    			return true;
        return false;
    }

    public void clear() {				//metodo per pulire il set
    	set.clear();
    }

    public boolean isEmpty() {			//metodo che controlla se il set Ã¨ vuoto, e restituisce true o false
    	return set.isEmpty();
    
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {				//metodo per calcolare l'hashcode del set
        return set.hashCode();
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {						// Confronto gli oggetti ordinati di due ArrayList e mi restituisce True se gli oggetti ordinati sono uguali tra le due Collection , False altrimenti
    	@SuppressWarnings({ "unchecked", "rawtypes" })
		ArrayList<Integer> set2 = ((MyMultiset)obj).getSet();
    	Collections.sort(set2);
    	Collections.sort(set);
    	if(set.equals(set2)) {
        	@SuppressWarnings({ "rawtypes", "unchecked" })
			ArrayList<Integer> array_count2 = ((MyMultiset)obj).getArray_count();
        	Collections.sort(array_count2);
        	Collections.sort(array_count);
        	if(array_count.equals(array_count2))
        		return true;
    	}
        return false;
    }
    
    
    public ArrayList<Integer> getSet() {				//Metodo accessorio get ,per farmi ritornare il valore del set
		return set;
	}

	public void setSet(ArrayList<Integer> set) {			//Metodo accessorio set ,imposto il valore del set
		this.set = set;
	}
	
    public ArrayList<Integer> getArray_count() {			//Metodo accessorio get, per farmi ritornare il valore di array_count
		return array_count;
	}

	public void setArray_count(ArrayList<Integer> array_count) {	//Metodo accessorio set , imposto l'array_count per i valori che mi passa la lista
		this.array_count = array_count;
	}
	
	public int searchIndex(Integer element) {		//scorre il set e confronto l'elemento se Ã¨ uguale a quell'indice dato del set
		int index=-1;
	   	 for(int i=0; i<set.size();i++)
			 if(element.equals(set.get(i)))
				 index=i;
   	 
	   	 return index;								//restituisce l'indice degli elementi cercati
	}

}
