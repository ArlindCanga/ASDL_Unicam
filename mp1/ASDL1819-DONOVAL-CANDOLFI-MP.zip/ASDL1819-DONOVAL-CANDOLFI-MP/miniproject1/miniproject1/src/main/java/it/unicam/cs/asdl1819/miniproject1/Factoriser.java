package it.unicam.cs.asdl1819.miniproject1;

import java.util.SortedSet;

/**
* Un fattorizzatore è un agente che fattorizza un qualsiasi numero naturale nei
 * sui fattori primi.
 * 
 * @author Luca Tesei (template) **Donoval Candolfi** (implementazione)
 *
 */
public class Factoriser {
   
	
	
	/**
     * Fattorizza un numero restituendo il multinsieme dei suoi fattori primi.
     * La molteplicitÃ  di ogni fattore primo esprime quante volte il fattore
     * stesso divide il numero fattorizzato. Per convenzione non viene mai
     * restituito il fattore 1. Il minimo numero fattorizzabile Ã¨ 1. In questo
     * caso viene restituito un multinsieme vuoto.
     * 
     * @param n
     *              un numero intero da fattorizzare
	 * @param  
     * @return il multinsieme dei fattori primi di n
     * @throws IllegalArgumentException
     *                                      se si chiede di fattorizzare un
     *                                      numero minore di 1.
     */
    public Multiset<Integer> getFactors(int n) {
    	int residuoDaFatt=n;
        Multiset<Integer> fattori = new MyMultiset<Integer>();  //costruttore Multiset di interi della variabile fattori

        if(residuoDaFatt==1)              
        return fattori;              
          
        CrivelloDiEratostene crEratostene = new CrivelloDiEratostene(n);		//passo i valori del crivello nella variabile cr
          SortedSet<Integer> num_Primi = crEratostene.getPrimes();             //ordino i numeri primi calcolati nel crivello in un SortedSet
          
          
          if(residuoDaFatt<1)
              throw new IllegalArgumentException();
          
          while(residuoDaFatt > 1)  	//calcolo i fattori
      {
              int divisore = num_Primi.first();		//inserisco nel divisore il primo numero primo che incontra
              num_Primi.remove(divisore);			//rimuovo il divisore dai numeri primi
             
              while(residuoDaFatt%divisore==0)		//continua ad eseguire la divisione finchÃ¨ dÃ  resto 0
           {
                  residuoDaFatt /= divisore;		//calcola il numero residuo da fattorizzare
                  fattori.add(divisore);  					//aggiunge il divisore ai fattori
                  
           }        
      }     
          return fattori;      			//ritorna i fattori

    }
}