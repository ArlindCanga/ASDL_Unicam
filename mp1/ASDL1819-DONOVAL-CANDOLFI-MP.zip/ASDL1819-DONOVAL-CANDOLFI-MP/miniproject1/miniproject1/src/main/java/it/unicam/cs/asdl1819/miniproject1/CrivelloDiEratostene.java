package it.unicam.cs.asdl1819.miniproject1;

import java.util.TreeSet; // Utilizzare questa classe per il SortedSet
import java.util.ArrayList;
import java.util.SortedSet;

/**
 * Il crivello di Eratostene è un modo per determinare tutti i numeri primi da
 * {@code 1} a un certo intero {@code n} assegnato.
 * 
 * @author Luca Tesei (template), ** Donoval Candolfi** (implementazione)
 *
 */
public class CrivelloDiEratostene {

	ArrayList<Integer> raccolta = new ArrayList<Integer>();   //creo un arraylist di interi di nome raccolta

	


    /**
     * Costruisce il crivello di Eratostene fino a un certo numero. Il numero
     * deve essere almeno 2.
     * 
     * @param n
     *              numero di entrate nel crivello
     * 
     * @throws IllegalArgumentException
     *                                      se il numero {@code n} Ã¨ minore di
     *                                      {@code 2}
     */
    public CrivelloDiEratostene(int n) {
    	if(n<2)
		throw new IllegalArgumentException() ;  //controlla che il numero passato dal crivello sia minore di 2
    											// e lancia l'eccezione

    	for ( int i=1; i <= n ; i++) 			
        		raccolta.add(i) ;				//aggiungo n valori dentro l'ArrayList raccolta
    }

    /**
     * Cerca nel crivello l'indice del numero primo successivo a un numero dato.
     * 
     * @param n
     *              il numero da cui partire
     * @return il numero primo successivo a {@code n} in questo crivello oppure
     *         -1 se in questo crivello non ci sono numeri primi maggiori di
     *         {@code n}
     * @throws IllegalArgumentException
     *                                      se il numero passato {@code n}
     *                                      eccede la capacitÃ  di questo
     *                                      crivello o se Ã¨ un numero minore di
     *                                      1.
     */
    public int nextPrime(int n) {		
    	if (n<1)
    		throw new IllegalArgumentException () ; 
    	if (n>raccolta.size())
    		throw new IllegalArgumentException();
    	
    				for(int j=n+1; j<= raccolta.size(); j++)
	    	    		if (isPrime(j)) {
	    	    			return j;
	    	    		}
    				return -1;
    }

    /**
     * Restituisce la raccolta dei numeri primi calcolati attraverso questo
     * crivello. Per convenzione il numero primo {@code 1} non viene incluso nel
     * risultato.
     * 
     * @return la raccolta dei numeri primi calcolati attraverso questo crivello.
     */
    public SortedSet<Integer> getPrimes() {
    	SortedSet<Integer> numeriPrimi = new TreeSet<Integer>();

    	for(int j=1; j<= raccolta.size()-1; j++)
    		if (isPrime(raccolta.get(j))) {
    			numeriPrimi.add(raccolta.get(j));
    		}
        return numeriPrimi;
    }

    /**
	 * @param raccolta the raccolta to set
	 */
	public void setInsieme(ArrayList<Integer> raccolta) {   
		this.raccolta = raccolta;
	}

	/**
     * Restituisce la capacitÃ  di questo crivello, cioÃ¨ il numero massimo di
     * entrate.
     * 
     * @return la capacitÃ  di questo crivello
     */
    public int getCapacity() {
    	
        return raccolta.size();
    }
    
    /**
     * Controlla se un numero Ã¨ primo. PuÃ² rispondere solo se il numero passato
     * come parametro Ã¨ minore o uguale alla capacitÃ  di questo crivello.
     * 
     * @param n
     *              il numero da controllare
     * @return true se il numero passato Ã¨ primo
     * @throws IllegalArgumentException
     *                                      se il numero passato {@code n}
     *                                      eccede la capacitÃ  di questo
     *                                      crivello o se Ã¨ un numero minore di
     *                                      1.
     */
    public boolean isPrime(int n) {
    	if (n<1 || n>raccolta.size()) 
    		throw new IllegalArgumentException(); 
 
    	if (n>=1 && n<=3)  
    	    return true;
    	if (n%2==0)  
    	    return false;
    	for (int i=3; i*i<=n; i=i+2)
    	    if ( n%i==0)   
    	       return false;    
    	return true; 
    }
}