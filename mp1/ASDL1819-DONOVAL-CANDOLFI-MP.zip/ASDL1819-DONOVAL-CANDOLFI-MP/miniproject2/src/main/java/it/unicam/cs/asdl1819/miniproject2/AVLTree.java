package it.unicam.cs.asdl1819.miniproject2;
/**
 * 
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Un AVLTree � un albero binario di ricerca che si mantiene sempre bilanciato.
 * In questa particolare classe si possono inserire elementi ripetuti di tipo
 * {@code E} e non si possono inserire elementi {@code null}.
 * 
 * @author Luca Tesei   ** Donoval Candolfi** (implementazione) 
 * 
 * @param E il tipo degli elementi che possono essere inseriti in questo
 *          AVLTree. La classe {@code E} deve avere un ordinamento naturale
 *          definito tra gli elementi.
 *
 */
public class AVLTree<E extends Comparable<E>> {
	// puntatore al nodo radice, se questo puntatore � null allora questo
	// AVLTree � vuoto
	private AVLTreeNode root;

	// Numero di elementi inseriti in questo AVLTree, comprese le ripetizioni
	private int size;

	// Numero di nodi in questo AVLTree
	private int numberOfNodes;

	private static final int BALANCED = 2;
	private static final int NOTBALANCED_R = -2;
    private static final int MORELEFT = 1;
	/**
	 * Costruisce un AVLTree vuoto.
	 */
	public AVLTree() {
		root = null;							//inizializzo l'albero a null
		size = 0;								//inizializzo la size a 0
		numberOfNodes = 0;						//inizializzo il numero dei nodi a 0
	}

	/**
	 * Costruisce un AVLTree che consiste solo di un nodo radice.
	 * 
	 * @param rootElement l'informazione associata al nodo radice
	 * @throws NullPointerException se l'elemento passato � null
	 */
	public AVLTree(E rootElement) {
		if (rootElement == null)
			throw new NullPointerException();
		this.root = new AVLTreeNode(rootElement);			//creo nell'albero un nodo radice
		size = 1;
		numberOfNodes = 1;
	}

	/**
	 * Determina se questo AVLTree � vuoto.
	 * 
	 * @return true, se questo AVLTree � vuoto.
	 */
	public boolean isEmpty() {
		return (this.root == null);
	}

	/**
	 * Restituisce il numero di elementi contenuti in questo AVLTree. In caso di
	 * elementi ripetuti essi vengono contati pi� volte.
	 * 
	 * @return il numero di elementi di tipo {@code E} presenti in questo AVLTree.
	 */
	public int getSize() {
		return this.size;
	}

	/**
	 * Restituisce il numero di nodi in questo AVLTree.
	 * 
	 * @return il numero di nodi in questo AVLTree.
	 */
	public int getNumberOfNodes() {
		return this.numberOfNodes;
	}

	/**
	 * Restituisce l'altezza di questo AVLTree. Se questo AVLTree � vuoto viene
	 * restituito il valore -1.
	 * 
	 * @return l'altezza di questo AVLTree, -1 se questo AVLTree � vuoto.
	 */
	public int getHeight() {
		if (isEmpty())
			return -1;
		return root.getHeight();
	}

	/**
	 * @return the root
	 */
	public AVLTreeNode getRoot() {
		return root;
	}

	/**
	 * @param root the root to set
	 */
	public void setRoot(AVLTreeNode root) {
		this.root = root;
	}

	/**
	 * Determina se questo AVLTree � bilanciato. L'albero � bilanciato se tutti i
	 * nodi hanno un fattore di bilanciamento compreso tra -1 e +1.
	 * 
	 * @return true, se il fattore di bilanciamento di tutti i nodi dell'albero �
	 *         compreso tra -1 e +1.
	 */
	public boolean isBalanced() {
		if (root.isBalanced())
			return true;
		return false;
	}

	/**
	 * Inserisce un nuovo elemento in questo AVLTree. Se l'elemento � gi� presente
	 * viene incrementato il suo numero di occorrenze.
	 * 
	 * @param el l'elemento da inserire.
	 * @return il numero di confronti tra elementi della classe {@code E} effettuati
	 *         durante l'inserimento
	 * @throws NullPointerException se l'elemento {@code el} � null
	 */
	public int insert(E el) {
		if (el == null)
			throw new NullPointerException();
		if(root==null)
		{
			root=new AVLTreeNode(el);
			return 0;
		}
		int comp = root.insert(el);

		return comp;
		
		
	}

	/**
	 * Determina se questo AVLTree contiene un certo elemento.
	 * 
	 * @param el l'elemento da cercare
	 * @return true se l'elemento � presente in questo AVLTree, false altrimenti.
	 * @throws NullPointerException se l'elemento {@code el} � null
	 */
	public boolean contains(E el) {
		if (el == null)
			throw new NullPointerException();
		AVLTreeNode currentNode = root;				//assegno il nodo a currentNode
		while (currentNode != null) {
			int comp = el.compareTo(currentNode.el);   //faccio i confronti tra i valori del nodo
			if (comp == 0) {
				return true;
			}else if (comp <0) {
				currentNode = currentNode.left;
			}else {
				currentNode = currentNode.right;
			}
		}
		return false;
		
	}

	/**
	 * Determina se un elemento � presente in questo AVLTree e ne restituisce il
	 * relativo nodo.
	 * 
	 * @param el l'elemento da cercare
	 * @return il nodo di questo AVLTree che contiene l'elemento {@code el} e la sua
	 *         molteplicit�, oppure {@code null} se l'elemento {@code el} non �
	 *         presente in questo AVLTree.
	 * @throws NullPointerException se l'elemento {@code el} � null
	 * 
	 */
	public AVLTreeNode getNodeOf(E el) {
		if (el == null)
			throw new NullPointerException();
		return root.search(el);
	}

	/**
	 * Determina il numero di occorrenze di un certo elemento in questo AVLTree.
	 * 
	 * @param el l'elemento di cui determinare il numero di occorrenze
	 * @return il numero di occorrenze dell'elemento {@code el} in questo AVLTree,
	 *         zero se non � presente.
	 * @throws NullPointerException se l'elemento {@code el} � null
	 */
	public int getCount(E el) {
		if (el == null)
			throw new NullPointerException();
		AVLTreeNode temp = getNodeOf(el);
		if(temp != null)
			return (temp.getCount());
		else
			return 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		String descr = "AVLTree [root=" + root.el.toString() + ", size=" + size + ", numberOfNodes=" + numberOfNodes
				+ "]\n";
		return descr + this.root.toString();
	}

	/**
	 * Restituisce la lista degli elementi contenuti in questo AVLTree secondo
	 * l'ordine determinato dalla visita in-order. Per le propriet� dell'albero AVL
	 * la lista ottenuta conterr� gli elementi in ordine crescente rispetto
	 * all'ordinamento naturale della classe {@code E}. Nel caso di elementi
	 * ripetuti, essi appaiono pi� volte nella lista consecutivamente.
	 * 
	 * @return la lista ordinata degli elementi contenuti in questo AVLTree, tenendo
	 *         conto della loro molteplicit�.
	 */
	public List<E> inOrderVisit() {
		return root.inOrderVisit();
	}

	/**
	 * Restituisce l'elemento minimo presente in questo AVLTree.
	 * 
	 * @return l'elemento minimo in questo AVLTree, {@code null} se questo AVLTree �
	 *         vuoto.
	 */
	public E getMinimum() {
		if (isEmpty())
			return null;
		return root.getMinimum().getEl();
	}

	/**
	 * Restituisce l'elemento massimo presente in questo AVLTree.
	 * 
	 * @return l'elemento massimo in questo AVLTree, {@code null} se questo AVLTree
	 *         � vuoto.
	 */
	public E getMaximum() {
		if (isEmpty())
			return null;
		return root.getMaximum().getEl(); 
	}

	/**
	 * Restituisce l'elemento <b>strettamente</b> successore, in questo AVLTree, di
	 * un dato elemento. Si richiede che l'elemento passato sia presente
	 * nell'albero.
	 * 
	 * @param el l'elemento di cui si chiede il successore
	 * @return l'elemento <b>strettamente</b> successore, rispetto all'ordinamento
	 *         naturale della classe {@code E}, di {@code el} in questo AVLTree,
	 *         oppure {@code null} se {@code el} � l'elemento massimo.
	 * @throws NullPointerException     se l'elemento {@code el} � null
	 * @throws IllegalArgumentException se l'elemento {@code el} non � presente in
	 *                                  questo AVLTree.
	 */
	public E getSuccessor(E el) {
		if (el == null)
			throw new NullPointerException();
		if (!contains(el))
			throw new IllegalArgumentException();
		if (el.compareTo(getMaximum()) == 0)
			return null;
		return getNodeOf(el).getSuccessor().getEl();
	}

	/**
	 * Restituisce l'elemento <b>strettamente</b> predecessore, in questo AVLTree,
	 * di un dato elemento. Si richiede che l'elemento passato sia presente
	 * nell'albero.
	 * 
	 * @param el l'elemento di cui si chiede il predecessore
	 * @return l'elemento <b>strettamente</b> predecessore rispetto all'ordinamento
	 *         naturale della classe {@code E}, di {@code el} in questo AVLTree,
	 *         oppure {@code null} se {@code el} � l'elemento minimo.
	 * @throws NullPointerException     se l'elemento {@code el} � null
	 * @throws IllegalArgumentException se l'elemento {@code el} non � presente in
	 *                                  questo AVLTree.
	 */
	public E getPredecessor(E el) {
		if (el == null)
			throw new NullPointerException();
		if (!contains(el))
			throw new IllegalArgumentException();
		if (el.compareTo(getMinimum()) == 0)
			return null;
		return getNodeOf(el).getPredecessor().getEl();
	}

	/**
	 * Gli elementi di questa classe sono i nodi di un AVLTree, che � la classe
	 * "involucro" della struttura dati.
	 * 
	 * @author Luca Tesei
	 *
	 */
	public class AVLTreeNode {
		// etichetta del nodo
		private E el;

		// molteplicit� dell'elemento el
		private int count;

		// sottoalbero sinistro
		private AVLTreeNode left;

		// sottoalbero destro
		private AVLTreeNode right;

		// genitore del nodo, null se questo nodo � la radice dell'AVLTree
		private AVLTreeNode parent;

		// altezza del sottoalbero avente questo nodo come radice
		private int height;

		/**
		 * Create an AVLTreeNode as a root leaf
		 * 
		 * @param el the element
		 */
		public AVLTreeNode(E el) {
			this.el = el;
			this.count = 1;
			this.left = null;
			this.right = null;
			this.parent = null;
			this.height = 0;
		}

		/**
		 * Create an AVLTreeNode node containing one element to be considered child of
		 * the given parent.
		 * 
		 * @param el     the element
		 * @param parent the parent of the node
		 */
		public AVLTreeNode(E el, AVLTreeNode parent) {
			this.el = el;
			this.count = 1;
			this.left = null;
			this.right = null;
			this.parent = parent;
			this.height = 0;
		}

		/**
		 * Restituisce il nodo predecessore di questo nodo. Si suppone che esista un
		 * nodo predecessore, cio� che questo nodo non contenga l'elemento minimo del
		 * sottoalbero di cui � radice.
		 * 
		 * @return il nodo predecessore
		 */
		public AVLTreeNode getPredecessor() {
			if (left != null)
				if (left.getMaximum() != null)
					return left.getMaximum();
			for (AVLTreeNode nodo = this; nodo.parent != null; nodo = nodo.parent) {
				if (nodo != nodo.parent.left)
					return nodo.parent;
			}
			return null;
		}

		/**
		 * Restituisce il nodo successore di questo nodo. Si suppone che esista un nodo
		 * successore, cio� che questo nodo non contenga l'elemento massimo del
		 * sottoalbero di cui � radice.
		 * 
		 * @return il nodo successore
		 */
		public AVLTreeNode getSuccessor() {
			if (right != null)
				if (right.getMinimum() != null)
					return right.getMinimum();
			for (AVLTreeNode node = this; node.parent != null; node = node.parent) {
				if (node != node.parent.right)
					return node.parent;
			}
			return null;
		}

		/**
		 * Restituisce il nodo contenente l'elemento massimo del sottoalbero di cui
		 * questo nodo � radice.
		 * 
		 * @return il nodo contenente l'elemento massimo del sottoalbero di cui questo
		 *         nodo � radice.
		 */
		public AVLTreeNode getMaximum() {
			AVLTreeNode temp = this;
			while (temp.getRight() != null)
				temp = temp.getRight();
			return temp;
		}

		/**
		 * Restituisce il nodo contenente l'elemento minimo del sottoalbero di cui
		 * questo nodo � radice.
		 * 
		 * @return il nodo contenente l'elemento minimo del sottoalbero di cui questo
		 *         nodo � radice.
		 */
		public AVLTreeNode getMinimum() {
			AVLTreeNode temp = this;
			while (temp.getLeft() != null)
				temp = temp.getLeft();
			return temp;
		}

		/**
		 * Determina se questo � un nodo foglia.
		 * 
		 * @return true se questo nodo non ha figli, false altrimenti.
		 */
		public boolean isLeaf() {
				if (getLeft() != null || getRight() != null)      //se ha ramo destro e sinistro non � foglia
				return false;
			return true;
		}

		/**
		 * Restituisce l'altezza del sottoalbero la cui radice � questo nodo.
		 * 
		 * @return l'altezza del sotto albero la cui radice � questo nodo.
		 */
		public int getHeight() {
			return this.height;
		}

		/**
		 * Aggiorna l'altezza del sottoalbero la cui radice � questo nodo supponendo che
		 * l'altezza dei nodi figli sia gi� stata aggiornata.
		 */
		public void updateHeight() {
			if (this.getLeft() == null && this.getRight() == null)      // se non ho nulla setto l'altezza a 0 dell'albero
				setHeight(0);
	        else
	        {
	            int Hleft = 0;
	            int Hright = 0;
	            if (this.left != null)
	            {
	                Hleft++;
	                Hleft += this.getLeft().getHeight();
	            }
	            if (this.right != null)
	            {
	                Hright++;
	                Hright += this.getRight().getHeight();
	            }
	            setHeight(Math.max(Hleft,Hright));
	        	if(this.parent != null) {					//se l'elemento corrente � un genitore aggiorno l'altezza
					this.parent.updateHeight();
	        	}
	        }
			

		}

		/**
		 * Determina il fattore di bilanciamento di questo nodo. Se il nodo � una foglia
		 * il fattore di bilanciamento � 0. Se il nodo ha solo il figlio sinistro allora
		 * il fattore di bilanciamento � l'altezza del figlio sinistro + 1. Se il nodo
		 * ha solo il figlio destro allora il fattore di bilanciamento � l'altezza del
		 * figlio destro + 1, moltiplicata per -1. Se il nodo ha entrambi i figli il
		 * fattore di bilanciamento � l'altezza del figlio sinistro meno l'altezza del
		 * figlio destro.
		 * 
		 * @return il fattore di bilanciamento di questo nodo.
		 */
		public int getBalanceFactor() {
			int balance = 0;
			if (this.isLeaf())
				return balance;
			if (getLeft() != null && getRight() == null)
				balance = getLeft().getHeight() + 1;
			if (getRight() != null && getLeft() == null)
				balance = (getRight().getHeight() + 1) * -1;
			if (getLeft() != null && getRight() != null)
				balance = getLeft().getHeight() - getRight().getHeight();
			return balance;
		}

		/**
		 * Determina se questo nodo e tutti i suoi discendenti hanno un fattore di
		 * bilanciamento compreso tra -1 e 1.
		 * 
		 * @return true se questo nodo e tutti i suoi discendenti sono bilanciati, false
		 *         altrimenti.
		 */
		public boolean isBalanced() {
			if (this.getBalanceFactor() >= -1 && this.getBalanceFactor() <= 1)   //se rientra in quei valori l'albero � bilanciato
				return true;
			/* If we reach here then tree is not height-balanced */
			return false;
		}

		/**
		 * @return the el
		 */
		public E getEl() {
			return el;
		}

		/**
		 * @param el the el to set
		 */
		public void setEl(E el) {
			this.el = el;
		}

		/**
		 * @return the count
		 */
		public int getCount() {
			return count;
		}

		/**
		 * @param count the count to set
		 */
		public void setCount(int count) {
			this.count = count;
		}

		/**
		 * @return the left
		 */
		public AVLTreeNode getLeft() {
			return left;
		}

		/**
		 * @param left the left to set
		 */
		public void setLeft(AVLTreeNode left) {
			this.left = left;
		}

		/**
		 * @return the right
		 */
		public AVLTreeNode getRight() {
			return right;
		}

		/**
		 * @param right the right to set
		 */
		public void setRight(AVLTreeNode right) {
			this.right = right;
		}

		/**
		 * @return the parent
		 */
		public AVLTreeNode getParent() {
			return parent;
		}

		/**
		 * @param parent the parent to set
		 */
		public void setParent(AVLTreeNode parent) {
			this.parent = parent;
		}

		/**
		 * @param height the height to set
		 */
		public void setHeight(int height) {
			this.height = height;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			StringBuffer s = new StringBuffer();
			s.append("(");
			s.append(this.el);
			s.append(", ");
			if (this.left == null)
				s.append("()");
			else
				s.append(this.left.toString());
			s.append(", ");
			if (this.right == null)
				s.append("()");
			else
				s.append(this.right.toString());
			s.append(")");
			return s.toString();
		}

		/**
		 * Ricerca un elemento a partire da questo nodo.
		 * 
		 * @param el the element to search for
		 * 
		 * @return the node containing the element or null if the element is not found
		 */
		public AVLTreeNode search(E el) {
			AVLTreeNode temp = root;
			while (temp != null) {
				int compare = el.compareTo(temp.el);     //faccio i confronti tra gli elementi per cercare 
				if (compare == 0)
					return temp;
				if (compare < 0)
					temp = temp.left;
				if (compare > 0)
					temp = temp.right;
			}
			return null;
		}

		/**
		 * Inserisce un elemento nell'albero AVL a partire da questo nodo. Se l'elemento
		 * � gi� presente ne aumenta semplicemente la molteplicit� di uno. Se l'elemento
		 * non � presente aggiunge un nodo nella opportuna posizione e poi procede al
		 * ribilanciamento dell'albero se l'inserimento del nuovo nodo provoca uno
		 * sbilanciamento in almeno un nodo.
		 * 
		 * @param el l'elemento da inserire
		 * 
		 * @return il numero di confronti tra elementi della classe {@code E} effettuati
		 *         durante l'inserimento.
		 */
		public int insert(E el) {
			AVLTreeNode nodo = null;
			int comp = 1;
			int compObj = this.el.compareTo(el);
			if (compObj < 0) {						//se confronto ed � minore , inserisco un nodo nel sottoalbero sinistro al figlio destro
				if (this.right != null) {
					comp += this.right.insert(el);
				} else {
					this.right = new AVLTreeNode(el, this);  // 
					this.updateHeight();
					nodo=this;
					while (nodo != null) {
						if (nodo.getBalanceFactor() == BALANCED || nodo.getBalanceFactor() == NOTBALANCED_R) {   //condizioni albero bilanciato / sbilanciato
							break;
						} else
							nodo = nodo.parent;
					}
					numberOfNodes++;
					size++;
				}
				if (nodo != null) {
					if (nodo.getBalanceFactor() == NOTBALANCED_R)// albero sbilanciato a destra
					{
						if (nodo.right != null && nodo.right.getBalanceFactor() == MORELEFT) // inserisco nel ramo sinistro
						{
							nodo.rightLeftRotation();
							AVLTreeNode temp = root;
							while (temp.parent != null) {
								temp = temp.parent;
							}
							root=temp;
							root.updateHeight();
						}
						if (nodo.right != null && nodo.right.getBalanceFactor() == -MORELEFT) // inserisco al ramo destro
						{
							nodo.rightRotation();
							AVLTreeNode temp = root;
							while (temp.parent != null) {
								temp = temp.parent;
							}
							root=temp;
							root.updateHeight();
						}

						nodo.updateHeight();
					}
					else if(nodo.getBalanceFactor() == BALANCED)
					{
						if (nodo.left != null && nodo.left.getBalanceFactor() == -MORELEFT) // inserisco al ramo sinistro
						{
						nodo.leftRightRotation();
						AVLTreeNode temp = root;
						while (temp.parent != null) {
							temp = temp.parent;
						}
						root=temp;
						root.updateHeight();
						}
					}
				}
			} else if (compObj > 0) {			//se confronto ed � maggiore , inserisco un nodo nel sottoalbero destro al figlio sinistro
				if (this.left != null) {
					comp += this.left.insert(el);
				} else {
					this.left = new AVLTreeNode(el, this);
					this.updateHeight();
					nodo=this;
					while (nodo != null) {
						if (nodo.getBalanceFactor() == BALANCED || nodo.getBalanceFactor() == NOTBALANCED_R) {
							break;
						} else
							nodo = nodo.parent;
					}
					numberOfNodes++;
					size++;
				}
				if (nodo != null) {
					if (nodo.getBalanceFactor() == BALANCED) {		// albero sbilanciato a sinistra
						if (nodo.left != null && nodo.left.getBalanceFactor() == MORELEFT) // inseriso nel ramo sinistro
						{
							nodo.leftRotation();
							AVLTreeNode temp = root;
							while (temp.parent != null) {
								temp = temp.parent;
							}
							root=temp;
							root.updateHeight();
						}
						if (nodo.left != null && nodo.left.getBalanceFactor() == - MORELEFT) // inserisco nel ramo destro
																						
						{
							nodo.leftRightRotation();
							AVLTreeNode temp = root;
							while (temp.parent != null) {
								temp = temp.parent;
							}
							root=temp;
							root.updateHeight();
						}
						nodo.updateHeight();
					}
					else if(nodo.getBalanceFactor() == NOTBALANCED_R)
					{
						if(nodo.right != null && nodo.right.getBalanceFactor() == MORELEFT)
						{
						nodo.rightLeftRotation();
						AVLTreeNode temp = root;
						while (temp.parent != null) {
							temp = temp.parent;
						}
						root=temp;
						root.updateHeight();
						}
					}
				}
			} else {
				this.count++;
				size++;
			}
			this.updateHeight();
			return comp;
		}
		/**
		 * Restituisce la lista dei nodi contenuti in questo AVLTreeNode secondo
		 * l'ordine determinato dalla visita in-order. Per le propriet� dell'albero AVL
		 * la lista ottenuta conterr� gli elementi in ordine crescente rispetto
		 * all'ordinamento naturale della classe {@code E}. Nel caso di elementi
		 * ripetuti, essi appaiono pi� volte nella lista consecutivamente.
		 * 
		 * @return la lista ordinata degli elementi contenuti in questo AVLTreeNode,
		 *         tenendo conto della loro molteplicit�.
		 */
		public List<E> inOrderVisit() {
			
			List<E> lista = new ArrayList<E>();
			if (getLeft() != null)
				lista.addAll(getLeft().inOrderVisit());
			for (int x = 0; x < getCount(); x++)
				lista.add(getEl());
			if (getRight() != null)
				lista.addAll(getRight().inOrderVisit());
			return lista;
		}

		private void rightRotation() {						//eseguo la rotazione a destra
			AVLTreeNode nodoA = this, nodoB = nodoA.right;
			nodoA.right = nodoB.left;
			if (nodoB.left != null) {
				nodoB.left.parent = nodoA;
			}
			nodoB.parent = nodoA.parent;
			nodoB.left = nodoA;
			nodoA.parent = nodoB;

			if (nodoB.parent != null) {
				if (nodoB.parent.right!=null && nodoB.parent.right.el == nodoA.el)
					nodoB.parent.right = nodoB;
				else {
					nodoB.parent.left = nodoB;
				}
			}
		}

		private void leftRotation() { 				//eseguo la rotazione a sinistra
			
			AVLTreeNode nodoA = this, nodoB = nodoA.left;
			nodoA.left = nodoB.right;
			if (nodoB.right != null) {
				nodoB.right.parent = nodoA;
			}
			nodoB.parent = nodoA.parent;
			nodoB.right = nodoA;
			nodoA.parent = nodoB;

			if (nodoB.parent != null) {
				if (nodoB.parent.left!=null && nodoB.parent.left.el == nodoA.el)
					nodoB.parent.left = nodoB;
				else {
					nodoB.parent.right = nodoB;
				}
			}

			nodoB.right.updateHeight();
		}

		private void leftRightRotation() { 			//eseguo la rotazione del nodo sinistro verso destra
		
			this.left.rightRotation();
			this.leftRotation();
		}

		private void rightLeftRotation() { 		//eseguo la rotazione del nodo destro verso sinistra

			this.right.leftRotation();
			this.rightRotation();
		}
	}
}